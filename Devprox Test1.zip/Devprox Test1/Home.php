<?php
  session_start();
    include('dbConn.php');
    $output = NULL;
    $Fname = $Surname = $IDNo = $DOB = "";
	
	if(isset($_POST['cancel'])){
		
		$Fname = $Surname = $IDNo = $DOB = "";
	}

    if(isset($_POST['submit']))
    {
    
        $Fname = $_POST['Fname'];
		$Surname = $_POST['Surname'];
        $IDNo = $_POST['IDNo'];
        $DOB = $_POST['DOB']; 
		
		$result=explode('-',$DOB);
		$date= $result[2];
		$month=$result[1];
		$year=$result[0];
		$newDOB=$date.'/'.$month.'/'.$year;
         
		function isDate($newDOB) {
        $matches = array();
        $pattern = '/^([0-9]{1,2})\\/([0-9]{1,2})\\/([0-9]{4})$/';
        if (!preg_match($pattern, $newDOB, $matches)) return false;
        if (!checkdate($matches[2], $matches[1], $matches[3])) return false;
        return true;
}
      
        $query = "SELECT * FROM tblUser WHERE IDNo = '$IDNo'";
    
        $checkIDExists = mysqli_query($conn,$query);
		#VALIDATING THE USER
        
        if(empty($Fname) || empty($Surname) || empty($IDNo) || empty($DOB))
        {
			echo "<script>alert('Fields cannot be empty')</script>";
           
        }
		if (!isDate($newDOB)) {
        echo "<script>alert('Date is invalid')</script>";
        }

      
        elseif(mysqli_num_rows($checkIDExists) == 1)
        {
			echo "<script>alert('Duplicate ID number found in database')</script>";
            
        }
		elseif(!is_numeric($IDNo) || strlen($IDNo)!==13){
			
			echo "<script>alert('ID Number is not vaild')</script>";
		}

        else
        {
			
            $query = "INSERT INTO tblUser (name,surname,IDno,DOB) VALUES ('$Fname','$Surname','$IDNo','$DOB')";
            $insertUser = mysqli_query($conn,$query);
            if ($insertUser == true) 
            {
                $output = "You have Sucessfully added a record";
				$Fname = $Surname = $IDNo = $DOB = "";
            
			}
        }
    
    
    }
	
?>



	<html>
		<head>
			<title>Devprox Test1</title>
			<link rel="stylesheet" type ="text/css" href="Teststyle.css"> <!-- CSS style sheet embeded here -->
		</head>
		
	<body>
	
		<div class="header">
		
  </div>
   <div class="container">
  
 	<form action="" method="POST" class="Home">
            <p class="login-text" style="font-size: 2rem; font-weight: 800;">Enter details</p>
		    <label>Firstname</Label>
			<div class="input-group">
				<input type="text" placeholder="" name="Fname" value="<?php echo $Fname ?>" required >
			</div>
			<label>Surname</Label>
			<div class="input-group">
				<input type="text" placeholder="" name="Surname" value="<?php echo $Surname ?>"  required>
            </div>
			<label>ID number </Label>
			<div class="input-group">
				<input type="text" placeholder="" name="IDNo" value="<?php echo $IDNo ?>" required>
            </div>
				<label>Date Of Birth </Label>
			<div class="input-group">
				<input type="date"  name="DOB" value="<?php echo $DOB ?>" required>
            </div>
			
            
			<div class="input-group">
				<button name="submit" class="btn" >POST </button>
				
			</div>
			<div class="input-group">
				
				<button name="cancel" class="btn" >CANCEL</button>
			</div>
			
			
		</form>
		
	
	</div>
	</body>
	</html>