<?php


$servername = "localhost";
$username = "root";
$dbname = "DevproxTest";




// when connection is called the three parameters are called

$con = mysqli_connect($servername,$username,"");

	if (!$con) 
	{
		
     # die("Connection failed: " . mysqli_connect_error());
		 	
    }
	else
	{
		//echo "<br>Connected successfully<br>";
	}	
		
	$selectDB = mysqli_select_db($con,$dbname);
	

		if (!$selectDB) 
		{

		  $sql = "CREATE DATABASE ".$dbname."";
		
		   mysqli_query($con, $sql); 
		
		
		   //echo "<br>Database ".$dbname." succesfully created<br>";

		} 
		else 
		{
			
		  // echo "<br>Database ".$dbname." already exsist<br>";
	    }
		
$conn = mysqli_connect($servername,'root','',$dbname);

$qrya= "DROP TABLE IF EXISTS `tblUser`";
$DropTableA = mysqli_query($conn, $qrya);

$sqla = "CREATE TABLE `tblUser` (
				  `cid` int(10) NOT NULL AUTO_INCREMENT,
				  `name` varchar(50) NOT NULL,
				  `surname` varchar(50) NOT NULL,
				  `IDno` varchar(50) NOT NULL,
				  `DOB` date NOT NULL,
				  PRIMARY KEY (`cid`)
				) ENGINE=InnoDB DEFAULT CHARSET=latin1";
				
				
		$CreateTableA = mysqli_query($conn, $sqla);
		
		
		if ($CreateTableA  == TRUE) 
		{
			
				
				loadUsers();
		} 
		else 
		{

			//echo "<br>Tables exsist";
			
		}
		
	//Function to load the 3 users	
		
		function loadUsers()//explictly called
     {
        $conn = mysqli_connect("localhost","root","","DevproxTest");
        $open = fopen('DemoUsers.txt','r'); //open the file stream into $open store it in the read mode

      while(!feof($open)) //loop through the lines
     {
	$getTextline = fgets($open) ;// stores each line into a variable called $getTextline
	$explodeLine = explode(",",$getTextline); // separate line valuse based on a delimeter
	
	list($name,$Surname,$IDno,$DOB) = $explodeLine;
	
  $sql = "INSERT INTO tblUser(name,surname,IDno,DOB) VALUES ('$name','$Surname','$IDno','$DOB')";
    mysqli_query($conn,$sql);
}
fclose($open); //colses the file stream	
}

?>