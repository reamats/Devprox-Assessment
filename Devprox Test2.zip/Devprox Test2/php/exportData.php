<?php
 session_start();
include('dbconfig.php');

 $result=$conn->query("SELECT * FROM csv_import ORDER BY userid ASC");
 
			 IF($result->num_rows>0){
				 
				$delimiter= ",";
				$filename="exported-data " .date('Y-m-d'). ".csv";
				
				$file= fopen('php://memory','w');
				$headers=array('ID','FIRSTNAME','INITIALS','SURNAME','DATE OF BIRTH','AGE');
				fputcsv($file,$headers,$delimiter);
				
				while($row=$result->fetch_assoc()){
					
					$Data= array($row['userid'],$row['firstname'],$row['initials'],$row['surname'],$row['DOB'],$row['age']);
					fputcsv($file,$Data,$delimiter);
					
				 }
				 fseek($file,0);
				 header('Content-Type: text/csv');
				 header('Content-Disposition: attachment; filename="'.$filename .'";');
				 
				 fpassthru($file);
				 }
				 exit;
			 
  
?>