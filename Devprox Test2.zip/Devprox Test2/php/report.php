<?php
  session_start();
  include('dbConn.php'); 
 
$output= fopen("php://output", "w");
fputcsv($output, array('Name','Initials','Surname','Date of Birth','Age')); 
fclose($output);

function Create_CSV_File(){
	//AN ARRAY OF FIRST NAMES
$firstnames = array(
    'Shailene Cindy',
    'Theo Landzy',
    'Miles West',
    'Kate Samantha',
    'Zoe Kim',
    'Ansel Busi',
    'Jai Faith',
    'Ashely Tshiamo',
	'Amandla Mbali',
    'Sharon',
    'Dwayne',
    'Liam',
    'Jennifer',
    'Tasha',
    'Cynthia',
    'Larenz',
	'Omari',
    'Cliff',
    'Cliff',
    'Alice',
    'Jamie'
);

//AN ARRAY OF SURNAMES
$surnames = array(
    'Woodley',
    'James',
    'Teller',
    'Winslet',
    'Kravits',
    'Elgort',
    'Courtney',
    'Judd',
    'Stenberg',
    'Conley',
	'Boyd',
    'Hemsworth',
    'Lawrence',
    'Smith',
    'Robinson',
    'Tate',
    'Hardwick',
    'Curtis',
    'Braga',
    'Hector'
	
);
		//Random first and last name
$random_firstname = $firstnames[mt_rand(0, sizeof($firstnames) - 1)];
$random_surname = $surnames[mt_rand(0,sizeof($surnames)-1)];


 
 //Generate random date of birth
$year= mt_rand(1900, date("Y"));
$month= mt_rand(1, 12);
$day= mt_rand(1, 28);

if($month<=9){
	$finalmonth="0".$month;
	$random_DOB = $day . "/".$finalmonth. "/". $year;
}
else{
	$random_DOB = $day . "/".$month. "/". $year;
}



//calculates age using DOB and current year
$age=(date('Y') - $year);

//Checks if user has 2 first names before creating initials
if ($random_firstname == trim($random_firstname) && str_contains($random_firstname, ' ')) {
	
$split_names = explode(' ', $random_firstname);
$Name1 = reset($split_names);
$Name2= end($split_names);

$initials= substr($Name1,0,1)."".substr($Name2,0,1);
    
}
else
{
	$initials=substr($random_firstname,0,1);
}

	


 

	
	$filename= 'output.csv';
	header("Content-type: text/csv");
	header("Content-Disposition: attachment; filename=$filename");
	header('Pragma: no-cache');
	header('Expires:0');
	
	$output= fopen("php://output", "w");
	
	$results= array(
	array($random_firstname,$initials,$random_surname,$random_DOB,$age)
	
	);
	
	
	foreach($results as $row)
	{
		fputcsv($output, $row);
		
	}
	
	fclose($output);
	
	
}


 if(isset($_POST['generate'])){

 $iteration = $_POST['iteration'];	 
	 
if(empty($iteration)){
	echo "<script>alert('No input provided to generate records')</script>";
}
else{
	
	
	
for($i=0;$i<=$iteration;$i++){

	Create_CSV_File();
	

	
}
}

 }
		

 
?>