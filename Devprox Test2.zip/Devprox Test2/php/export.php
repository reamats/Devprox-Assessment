<?php
  session_start();
 include('dbconfig.php');
  
?>

<!DOCTYPEhtml>
<html lang="en">
<head>
   <meta charset="utf-8">
   <title> Export From database to CSV</title>
   
  <! -- Bootstrap CDN -->
    
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	
	</head>
	<body>
	<div class="container">
	<h2> Data List </h2>
	
	   <div class="row">
	   <div class="col-md-12 head">
	   <div class="float-right">
	   <a href="exportData.php" class="btn btn-success"><i class="dwn"></i>Export</a>
	   </div>
	   </div>
	   
	   <table class="table table-striped table-bordered">
	     <thead class="thead-dark">
		   <tr>
		     <th>#ID</th>
			 <th>Firstname</th>
			 <th>Initials</th>
			 <th>Surname</th>
			 <th>Date Of Birth</th>
			 <th>Age</th>
			 </tr>
			 </thead>
			 <tbody>
			 <?php
			 //fetch data from database
			 
			 $result=$conn->query("SELECT * FROM csv_import ORDER BY userid ASC");
			 IF($result->num_rows>0){
				 while($row=$result->fetch_assoc()){
					 ?>
				 <tr>
					 <td><?php echo $row['userid'];?></td>
					 <td><?php echo $row['firstname'];?></td>
					 <td><?php echo $row['initials'];?></td>
					 <td><?php echo $row['surname'];?></td>
					 <td><?php echo $row['DOB'];?></td>
					 <td><?php echo $row['age']?></td>
				 </tr>
				 <?php
			 }
			 }else{
				 
				 ?>
				 
				 <tr><td calspan="7"> No user found...</td></tr>
				 <?php
			 }
			 ?>
			 
			 </tbody>
			 </table>
	    </div>
	</div>
	</body>
	</html>