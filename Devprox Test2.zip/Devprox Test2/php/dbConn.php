<?php


$servername = "localhost";
$username = "root";
$dbname = "DevproxTest";




// when connection is called the three parameters are called

$con = mysqli_connect($servername,$username,"");

	if (!$con) 
	{
		
     # die("Connection failed: " . mysqli_connect_error());
		 	
    }
	else
	{
		//echo "<br>Connected successfully<br>";
	}	
		
	$selectDB = mysqli_select_db($con,$dbname);
	

		if (!$selectDB) 
		{

		  $sql = "CREATE DATABASE ".$dbname."";
		
		   mysqli_query($con, $sql); 
		
		
		   //echo "<br>Database ".$dbname." succesfully created<br>";

		} 
		else 
		{
			
		  // echo "<br>Database ".$dbname." already exsist<br>";
	    }
		
$conn = mysqli_connect($servername,'root','',$dbname);


$qryb="DROP TABLE IF EXISTS `csv_import`";


$DropTableB = mysqli_query($conn, $qryb);


				
				
$sqlb= "CREATE TABLE `csv_import` (
				  `userid` int(10) NOT NULL AUTO_INCREMENT,
				  `firstname` varchar(50) NOT NULL,
				  `initials` varchar(3) NOT NULL,
				  `surname` varchar(50) NOT NULL,
				  `DOB` date NOT NULL,
				  `age` int(3) NOT NULL,
				  PRIMARY KEY (`userid`)
				) ENGINE=InnoDB DEFAULT CHARSET=latin1";
				
				
		
		$CreateTableB = mysqli_query($conn, $sqlb);
		
		
	
		


?>