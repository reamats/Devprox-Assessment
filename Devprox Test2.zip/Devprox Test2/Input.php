<?php
session_start();
include('php/dbConn.php');

//Importing CVS File to database
 
$conn = mysqli_connect($servername,'root','','DevproxTest');


if(isset($_POST["import"])){
	//$filename = $_FILES["file"]["name"];
	
	if($_FILES["file"]["name"]){
		$filename=explode('.',$_FILES["file"]["name"]);
		If($filename[1]=='csv'){
		$handle=fopen($_FILES["file"]["tmp_name"],"r");
		$SkipCount=0;
		$RecordCount=-2;
		while(($column = fgetcsv($handle,1000,",")) !== false){
			$RecordCount++;
			$SkipCount++;
			if($SkipCount>=2){
			
			$sqlInsert="Insert into csv_import(firstname,initials,surname,DOB,age) values( '".$column[0]."','".$column[1]."','".$column[2]."','".$column[3]."','".$column[4]."')";
			$result= mysqli_query($conn,$sqlInsert);
			
			
		}
		
		}
		if(!empty($result)){
				
				echo "<script>alert('CVS data successfully imported into database')</script>";
				
			}else{
				echo "CSV file import failed";
			}
		
	}
	fclose($handle);
	}
}
		


?>




<html>
		<head>
			<title>Devprox Test2</title>
			<link rel="stylesheet" type ="text/css" href="test2style.css"> <!-- CSS style sheet embeded here -->
		</head>
	
	<body>
	
		<div class="header">
		
  </div>
   <div class="container">
  
 	<form action="php/report.php" method="POST" class="Home">
            <p class="login-text" style="font-size: 2rem; font-weight: 800;">Enter details</p>
		    <label>Insert number of records you want to generate</Label>
			<div class="input-group">
				<input type="number" placeholder="" name="iteration"  >
			</div>
			<div class="input-group">
				<button name="generate" class="btn" >GENERATE</button>
				
			</div>
			
			
				
			
		
	</form>
	<form action="" method="POST" class="Home" enctype="multipart/form-data">
	      <label>Attatch .CSV file</Label>
			<div class="input-group">
				<input type="file"  name="file" id="file" accept=".csv"  >
            </div>
	<div class="input-group">
				<button type="submit" name="import" class="btn" >IMPORT</button>
			</div>
			
			<?php 
			if(!empty($result)){
			  echo $RecordCount." Records have been imported";
			}
			?>
    </form>
	<form action="php/export.php" method="POST" class="Home">
	
		<div class="input-group">
				<button type="submit" name="export" class="btn" >Export DB to CSV</button>
			</div>
			
	
	</form>
	</div>
	</body>
	</html>
	
